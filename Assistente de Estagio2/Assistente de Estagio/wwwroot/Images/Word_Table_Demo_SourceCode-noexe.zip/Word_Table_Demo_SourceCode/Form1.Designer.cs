﻿namespace Word_Table_Demo
{
    partial class frmWordTable
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnWordTable = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnWordTable
            // 
            this.btnWordTable.Location = new System.Drawing.Point(161, 52);
            this.btnWordTable.Name = "btnWordTable";
            this.btnWordTable.Size = new System.Drawing.Size(206, 23);
            this.btnWordTable.TabIndex = 0;
            this.btnWordTable.Text = "Create Word Table";
            this.btnWordTable.UseVisualStyleBackColor = true;
            this.btnWordTable.Click += new System.EventHandler(this.btnWordTable_Click);
            // 
            // frmWordTable
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(522, 132);
            this.Controls.Add(this.btnWordTable);
            this.Name = "frmWordTable";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Create Word Table";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnWordTable;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Word = Microsoft.Office.Interop.Word;

namespace Word_Table_Demo
{
    public partial class frmWordTable : Form
    {
        public frmWordTable()
        {
            InitializeComponent();
        }

        private void btnWordTable_Click(object sender, EventArgs e)
        {
            Word._Application objApp;
            Word._Document objDoc;
            try
            {
                object objMiss = System.Reflection.Missing.Value;
                object objEndOfDocFlag = "\\endofdoc"; /* \endofdoc is a predefined bookmark */

                //Start Word and create a new document.
                objApp = new Word.Application();
                objApp.Visible = true;
                objDoc = objApp.Documents.Add(ref objMiss, ref objMiss,
                    ref objMiss, ref objMiss);

                //Insert a paragraph at the end of the document.
                Word.Paragraph objPara2; //define paragraph object
                object oRng = objDoc.Bookmarks.get_Item(ref objEndOfDocFlag).Range; //go to end of the page
                objPara2 = objDoc.Content.Paragraphs.Add(ref oRng); //add paragraph at end of document
                objPara2.Range.Text = "Test Table Caption"; //add some text in paragraph
                objPara2.Format.SpaceAfter = 10; //defind some style
                objPara2.Range.InsertParagraphAfter(); //insert paragraph

                //Insert a 2 x 2 table, (table with 2 row and 2 column)
                Word.Table objTab1; //create table object
                Word.Range objWordRng = objDoc.Bookmarks.get_Item(ref objEndOfDocFlag).Range; //go to end of document
                objTab1 = objDoc.Tables.Add(objWordRng, 2, 2, ref objMiss, ref objMiss); //add table object in word document
                objTab1.Range.ParagraphFormat.SpaceAfter = 6;
                int iRow, iCols;
                string strText;
                for (iRow = 1; iRow <= 2; iRow++)
                    for (iCols = 1; iCols <= 2; iCols++)
                    {
                        strText = "row:" + iRow + "col:" + iCols;
                        objTab1.Cell(iRow, iCols).Range.Text = strText; //add some text to cell
                    }
                objTab1.Rows[1].Range.Font.Bold = 1; //make first row of table BOLD
                objTab1.Columns[1].Width = objApp.InchesToPoints(3); //increase first column width

                //Add some text after table
                objWordRng = objDoc.Bookmarks.get_Item(ref objEndOfDocFlag).Range;
                objWordRng.InsertParagraphAfter(); //put enter in document
                objWordRng.InsertAfter("THIS IS THE SIMPLE WORD DEMO : THANKS YOU.");

                object szPath = "test.docx"; //your file gets saved with name 'test.docx'
                objDoc.SaveAs(ref szPath);
            }
            catch (Exception ex)
            {

                MessageBox.Show("Error occurred while executing code : " + ex.Message);
            }
            finally
            {
                //you can dispose object here
            }

        }
    }
}
